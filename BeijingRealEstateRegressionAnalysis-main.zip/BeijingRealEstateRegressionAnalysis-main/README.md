# BeijingRealEstateRegressionAnalysis
Group Project for STAT 306, analysis and prediction of house prices in Beijing using regression models

Project Members: @eylultao @andyljd @KaysenYang
